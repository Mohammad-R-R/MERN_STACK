import React,{useState,useEffect} from 'react'
import List from '../components/List'
import axios from 'axios'

const ShowListPlayers = (props) => {
    const {children} = props;
    const [playerList, setPlayerList] = useState([]);
    useEffect(()=>{
        axios.get('http://localhost:8000/api/getplayers')
            .then(res=>setPlayerList(res.data))
            .catch(err=>console.log(err))

    },[])
    const deleteItem = (id) =>{
        setPlayerList(playerList.filter((item,idx)=>{
            return item._id !== id;
        }))
    }
    return (
        <div>
            {children}
            <List list={playerList} deleteProps={deleteItem}/>
        </div>
    )
}

export default ShowListPlayers
