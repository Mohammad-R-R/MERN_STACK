import React,{useState} from 'react'
import axios from 'axios'
const CreatePlayer = (props) => {
    const {children} = props;
    const [playerName, setPlayerName] = useState("");
    const [preferedPosition, setPreferedPosition] = useState("");
    const [errors, setErrors] = useState([]);
    const onSubmitHandler = (e)=>{
        e.preventDefault();
        if(playerName.length <2){
            return setErrors(["* Name must be at least 2 characters long"])
        }
        
        axios.post('http://localhost:8000/api/addplayers',{
            playerName,
            preferedPosition
        })
        .then(res=>console.log(res))
        .catch(err=>console.log(err))
        setErrors([])
    }

    return (
        <>
            {children}
            <form onSubmit={onSubmitHandler}>
                <fieldset>
                    <legend>Add Player:</legend>
                    <label>Player Name: </label>
                    <input type="text" placeholder="EnterPlayerName" onChange={e=>{setPlayerName(e.target.value)}} value={playerName}/>
                    {errors.length > 0 && errors[0]}
                    <br/>
                    <label>Preferred Position: </label>
                    <input type="text" placeholder="EnterEnterPreferred Position" onChange={e=>{setPreferedPosition(e.target.value)}} value={preferedPosition}/><br/>
                    <label><i>Supported Roles: 'Forward','Midfielder','Goalkeeper'</i></label>
                    <input type="submit" value="submit"/>
                </fieldset>
            </form>
        </>
    )
}

export default CreatePlayer
