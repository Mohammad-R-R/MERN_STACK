import React from 'react'
import './header.css'
import {Link } from "@reach/router"
const Header = (props) => {
    console.log(props.displayList.length);
    return (
        <>
            <ul className="nav">
                {
                    props.displayList.map((item, idx)=>{
                    return props.displayList.length -1 > idx ?
                        (<Link key={idx} to={item.path}><li >{item.desc} |</li></Link>) 
                        :
                        (<Link key={idx} to={item.path}><li >{item.desc} </li></Link>)
                    })
                }
                
            </ul>
        </>
    )
}

export default Header
