import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';

const useStyles = makeStyles({
    root: {
      width: '100%',
    },
    container: {
      maxHeight: 440,
    },
    header1:{
        backgroundColor:'grey'
    }
  });
  

const PlayersList = (props) => {
  const {list,deleteProps} = props;  
  const classes = useStyles();
  const onDeleteHandler = (e)=>{
    e.preventDefault();
    console.log(e.target.name)
    deleteProps(e.target.name);
  }
    return (
        <TableContainer className={classes.container}>
        <Table aria-label="sticky table">
          <TableHead className={classes.header1}> 
            <TableRow>
                <TableCell
                  key={0}
                  align={'left'}
                  style={{ minWidth: '20px'}}
                >
                  Team Name
                </TableCell>
                <TableCell
                  key={1}
                  align={'left'}
                  style={{ minWidth: '20px'}}
                >
                Prefered Position
                </TableCell>
                <TableCell
                  key={2}
                  align={'left'}
                  style={{ minWidth: '20px'}}
                >
                  Actions
                </TableCell>
            </TableRow>
            
          </TableHead>
          <TableBody>
            {
              list.map((item, idx)=>{
              return (
                <TableRow hover role="checkbox" tabIndex={-1} key={idx}>  
                  <TableCell align={'left'}>
                    {item.playerName}
                  </TableCell>
                  <TableCell align={'left'}>
                    {item.preferedPosition}
                  </TableCell>
                  <TableCell align={'left'}>
                    <input type="submit" value="Delete" onClick={onDeleteHandler} name={item._id}/>
                  </TableCell>
                </TableRow>
                )
              })
            }
            
          </TableBody>
        </Table>
      </TableContainer>
    );
}

export default PlayersList
