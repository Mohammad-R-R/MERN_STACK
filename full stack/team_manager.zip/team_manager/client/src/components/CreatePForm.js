import React from 'react'

const CreatePForm = () => {
    return (
        <div>
            
        </div>
    )
}

export default CreatePForm
