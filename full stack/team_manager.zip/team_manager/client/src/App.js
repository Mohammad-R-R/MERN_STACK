import './App.css';
import '@reach/router'
import CreatePlayer from './views/CreatePlayer'
import ShowListPlayers from './views/ShowListPlayers'
import Header from './components/Header'
import { Router} from "@reach/router"
function App() {
  const manageList = [{desc:"Manage Players", path:"players/list"}, {desc:"Manage Player Status",path:"status/game/"}];
  const playerList = [{desc:"List", path:"/players/list"}, {desc:"Add Player", path:"/players/addplayer"}];
  return (
    <div className="App">
    <Header displayList={manageList} />
    <section>
      <Router>
        <ShowListPlayers default path="/players/list/*">
          <Header default path="/" displayList={playerList}/>
        </ShowListPlayers>
        <CreatePlayer path="/players/addplayer/*">
          <Header path="/" displayList={playerList}/>
        </CreatePlayer>
      </Router>
    </section>
    </div>
  );
}

export default App;
